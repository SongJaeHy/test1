package day02.operator;

import java.util.Scanner;

public class Test09 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		System.out.print("�̸� ���� : ");
		String name = sc.next();
		int age = sc.nextInt();
		String email = sc.next();
		System.out.println("�̸� : " + name);
		System.out.println("���� : " + age);
		
	}
}

